import dash
import dash_core_components as dcc
import dash_html_components as html
import pandas as pd
import matplotlib
import os
import numpy as np
import plotly.offline as pyo
import plotly.graph_objs as go
import plotly.plotly as py
from datetime import datetime
import dashboard_utils as du
from flask import Flask
from dash.dependencies import Input, Output

path = r'C:\Users\Manuel.Corrado\Desktop\FOX\Adwords\Historicos_by_Day\*_campaign_performance\raw_data\*.csv'
sep = ','
lis,impr,conv,df = du.prepare_data_dias(path,sep)
df_dict = du.generate_adwords_hour_df(df,lis)


app = dash.Dash()

app.layout = html.Div(children=[
    html.H1('Gráfico de muestra'),
    dcc.Graph(
        figure = dict(
            data = [du.bar_generator(lis,conv,impr,'Bar title test')],
            layout = du.layout(title='Test title')
        ),

    ),
    html.H2('Fin del gráfico'),
    html.Hr(),
    html.Br(),
    html.Hr(),
    html.H2('A'),
    dcc.Dropdown(
        id = 'day-dropdown',
        options = [{'label':'Lunes', 'value':'Lunes'},
        {'label':'Martes', 'value':'Martes'},
        {'label':'Miércoles', 'value':'Miércoles'},
        {'label':'Jueves', 'value':'Jueves'},
        {'label':'Viernes', 'value':'Viernes'},
        {'label':'Sábado', 'value':'Sábado'},
        {'label':'Domingo', 'value':'Domingo'}],
        value = 'Lunes'
    ),
    dcc.Graph( id = 'hour-day-graph-filtered',
        #figure = dict(
        #    data = [du.scatter_generator(df_day['Hora'],df_day['Costo']),
        #            du.bar_generator(df_day['Hora'],df_day['Conversión'],df_day['Avg_CPA_Sab'],'Conversion x Hora')],
        #    layout = du.layout(title='Test scatter',legend_pos=dict(x=-.2,y=1.2))
        #)
    ),
    #html.Hr(size=50),
    #dcc.Graph( id = 'hour-day-graph-filtered')
])

@app.callback(
    Output('hour-day-graph-filtered', 'figure'),
    [Input('day-dropdown','value'),
    ]
)
def update_hour_figure(selected_day):
    df_day = df_dict['{}'.format(selected_day)]
    figure = dict(
        data=[du.scatter_generator(df_day['Hora'], df_day['Costo']),
              du.bar_generator(df_day['Hora'], df_day['Conversión'], df_day['Avg_CPA_Sab'], 'Conversion x Hora')],
        layout=du.layout(title=selected_day, legend_pos=dict(x=-.2, y=1.2))
    )
    return figure

#@app.callback(
#    Output('ad-creatives-graph-filtered','figure'),
#    [Input('creativities','value')]
#)
#def update_creativity_figure(selected_amount):





if __name__ == '__main__':
    app.run_server(debug=True)