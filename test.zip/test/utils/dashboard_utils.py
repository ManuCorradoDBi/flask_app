import pandas as pd
import numpy as np
import os
import glob
import plotly.offline as pyo
import plotly.graph_objs as go
import plotly.plotly as py
from datetime import datetime



#class Dashboard_utils():

def load_data(glob_path,sep):
    files = glob.glob(glob_path)
    df = pd.concat([pd.read_csv(i, sep=sep) for i in files])
    return df

def prepare_data_adwords(df):
    df['Cost'] = df['Cost'] / 1000000
    df['dayOfWeek'] = pd.DatetimeIndex(df['Day']).dayofweek
    dayDict = {6: 'Domingo', 0: 'Lunes', 1: 'Martes', 2: 'Miércoles', 3: 'Jueves', 4: 'Viernes', 5: 'Sábado'}
    df['Dia'] = df.dayOfWeek.map(dayDict)
    lista_dias = [i for i in dayDict.values()]
    conversiones_dia = [df[df['Dia'] == '%s' % i].Conversions.sum() for i in lista_dias]
    impresiones_dia = [df[df['Dia'] == '%s' % i].Impressions.sum() for i in lista_dias]
    Avg_cpa_dia = []
    for i in lista_dias:
        conv = df[df['Dia'] == '%s' % i].Conversions.sum()
        cost = df[df['Dia'] == '%s' % i].Cost.sum()
        resultado = cost / conv
        Avg_cpa_dia.append(resultado)
    return lista_dias,impresiones_dia,conversiones_dia,df

#def prepare_data_facebook(df):
#    df_creat = df.groupby('campaign_id')[['ad_id']].nunique().reset_index()
#    df_creat['ctr']=df.groupby('campaign_id')['ctr'].mean().reset_index().ctr
#    df_creat['spend']=df.groupby('campaign_id')['spend'].sum().reset_index().spend
#    df_creat.rename(columns={'ad_id':'cant. de creatividades'}, inplace=True)
#    bins = [0, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233]
#    names = ['0','1', '2','3-4','5-7','8-12','13-20','21-33','34-54','55-88','89-133','144-232']
#    df_creat['Range'] = pd.cut(df_creat['cant. de creatividades'], bins, labels=names)
#    df_graf= df_creat.groupby('Range')['ctr'].mean().reset_index()
#    df_graf2= df_creat.groupby('cant. de creatividades')['ctr'].mean().reset_index()

def prepare_data_dias(platform,path,sep):
    df = load_data(path, sep=sep)
    if plataform == 'adwords':
        return prepare_data_adwords(df)
    #return prepare_data_facebook(df)



def bar_generator(x,y,color,name,reversescale=True):
    trace = go.Bar(
        x = x,
        y = y,
        name = name,
        marker = dict(
            color = color,
            colorbar = dict(x=-0.2,len=1),
            colorscale = 'Greens',
            showscale = True,
            reversescale = reversescale
        )

    )

    return trace

def scatter_generator(x,y,color='crimson',trace_name='Trace',colorscale = 'Reds',reversescale = True,showscale = False):
    trace = go.Scatter(
        x = x,
        y = y,
        yaxis = 'y2',
        marker = dict(
            color = color,
            colorscale = colorscale,
            reversescale = reversescale,
            showscale = showscale

        ),
        name = trace_name,
        mode = 'lines'
    )

    return trace

#def layout_generator(title='Title',):
#    title = title

def layout(title='Title',legend_pos = dict(x=1,y=1),xaxis_title='Xaxis',yaxis_title='Yaxis',yaxis2_title='Yaxis2'):
    layout = go.Layout(
        title=title,
        yaxis=dict(
            title=yaxis_title
        ),
        xaxis=dict(
            title=xaxis_title
        ),
        yaxis2=dict(
            title=yaxis2_title,
            titlefont=dict(
                color='rgb(148, 103, 189)'
            ),
            tickfont=dict(
                color='rgb(148, 103, 189)'
            ),
            overlaying='y',
            side='right',

            rangemode='tozero'
        ),
        legend=legend_pos
    )

    return layout

def generate_adwords_hour_df(df,day_list):
    hour_list = [hour for hour in df['Hour of day'].unique()]
    df_per_day = {}
    df['Cost'] = df['Cost']/1000000
    for day in day_list:
        avg_cpa_hour = []
        cost = []
        conversion = []
        for hour in hour_list:
            conv_hour = df[(df['Hour of day']==hour) & (df['Dia']==day)].Conversions.sum()
            cost_hour = df[(df['Hour of day']==hour) & (df['Dia']==day)].Cost.sum()
            cpa = cost_hour/conv_hour
            avg_cpa_hour.append(cpa)
            cost.append(cost_hour)
            conversion.append(conv_hour)
        df_hour = pd.DataFrame(np.column_stack([hour_list,avg_cpa_hour,cost,conversion]))
        #df_hour = df_hour.apply(lambda x: x.round())
        df_hour.columns = ['Hora', 'Avg_CPA_Sab', 'Costo', 'Conversión']
        df_hour = df_hour.sort_values(['Hora'])
        #df_hour = df_hour.drop('index',axis=1)
        df_per_day.update({'{}'.format(day): df_hour})


    return df_per_day
