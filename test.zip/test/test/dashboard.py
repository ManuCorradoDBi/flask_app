import dash
import dash_core_components as dcc
import dash_html_components as html
import pandas as pd
import matplotlib
import os
import numpy as np
import plotly.offline as pyo
import plotly.graph_objs as go
import plotly.plotly as py
from datetime import datetime
from dashboard_utils import prepare_data, bar_generator

path = r'C:\Users\Manuel.Corrado\Desktop\FOX\Adwords\Historicos_by_Day\294_693_4819_campaign_performance\raw_data\*.csv'
sep = ','
lis,impr,conv = prepare_data(path,sep)

app = dash.Dash()

app.layout = html.Div(children=[
    html.H1('Gráfico de muestra'),
    dcc.Graph(
        figure = bar_generator(lis,impr,conv,name='Testeo - 1 - 2 - 3'),

    ),
    html.H2('Fin del gráfico'),
    html.Hr()
])

if __name__ == '__main__':
    app.run_server(debug=True)