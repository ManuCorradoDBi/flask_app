from setuptools import setup

setup(
    name='dashboard_utils',
    py_modules=['dashboard_utils']
)