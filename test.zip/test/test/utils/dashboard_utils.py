import pandas as pd
import os
import glob
import plotly.offline as pyo
import plotly.graph_objs as go
import plotly.plotly as py
from datetime import datetime



#class Dashboard_utils():

def load_data(glob_path,sep):
    files = glob.glob(glob_path)
    df = pd.DataFrame()
    for file in files:
        df_temp = pd.read_csv(file,sep=sep)
        df = pd.concat([df,df_temp])
    return df

def prepare_data(path,sep):
    df = load_data(path, sep=sep)
    df['Cost'] = df['Cost'] / 1000000
    df['dayOfWeek'] = pd.DatetimeIndex(df['Day']).dayofweek
    dayDict = {6: 'Domingo', 0: 'Lunes', 1: 'Martes', 2: 'Miércoles', 3: 'Jueves', 4: 'Viernes', 5: 'Sábado'}
    df['Dia'] = df.dayOfWeek.map(dayDict)
    lista_dias = [i for i in dayDict.values()]
    conversiones_dia = [df[df['Dia'] == '%s' % i].Conversions.sum() for i in lista_dias]
    impresiones_dia = [df[df['Dia'] == '%s' % i].Impressions.sum() for i in lista_dias]
    Avg_cpa_dia = []
    for i in lista_dias:
        conv = df[df['Dia'] == '%s' % i].Conversions.sum()
        cost = df[df['Dia'] == '%s' % i].Cost.sum()
        resultado = cost / conv
        Avg_cpa_dia.append(resultado)
    return lista_dias,impresiones_dia,conversiones_dia,


def bar_generator(x,y,color,name):
    trace = go.Bar(
        x = x,
        y = y,
        name = name,
        marker = dict(
            color = color,
            colorbar = dict(x=-0.2,len=1),
            colorscale = 'Reds',
            showscale = True
        )

    )
    layout = go.Layout(
        title='Conversiones - Impresiones por Día \ Rekket México',
        yaxis=dict(
            title='Conversiones'
        ),
        yaxis2=dict(
            title='Impresiones',
            titlefont=dict(
                color='rgb(148, 103, 189)'
            ),
            tickfont=dict(
                color='rgb(148, 103, 189)'
            ),
            overlaying='y',
            side='right',
            rangemode='tozero'
        ),
        legend=dict(y=1.2)
    )

    data = [trace]

    fig = go.FigureWidget(data=data,layout=layout)

    return fig

